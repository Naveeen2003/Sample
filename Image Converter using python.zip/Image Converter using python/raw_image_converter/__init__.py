"""Python Raw Image Converter.
CLI tool for batch raw image conversions

See https://github.com/achimoraites/Python-Image-Converter for more info.
"""

# Version of the package
__version__ = "1.1.3"
